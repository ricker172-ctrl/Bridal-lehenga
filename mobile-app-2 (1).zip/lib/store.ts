export const STORE = {
  name: "Bahurani Sarees Store",
  tagline: "Timeless Elegance for the Modern Bride",
  phoneDisplay: "+91 93040 93400",
  phoneRaw: "919304093400",
  telHref: "tel:+919304093400",
  addressShort: "Park Market, Hirapur, Dhanbad",
  addressFull: "Bahurani, Park Market, Hirapur, Dhanbad, Jharkhand 826007",
  mapsHref:
    "https://www.google.com/maps/search/?api=1&query=Bahurani%2C+Park+Market%2C+Hirapur%2C+Dhanbad%2C+Jharkhand+826007",
  hours: {
    openMinutes: 10 * 60 + 30, // 10:30 AM
    closeMinutes: 21 * 60 + 45, // 9:45 PM
    label: "10:30 AM – 9:45 PM, Daily",
  },
} as const

export function whatsappHref(message: string) {
  return `https://wa.me/${STORE.phoneRaw}?text=${encodeURIComponent(message)}`
}

export function formatINR(amount: number) {
  return `₹${amount.toLocaleString("en-IN")}`
}

/** WhatsApp link pre-filled with the exact product name and price. */
export function productWhatsappHref(product: Product) {
  const message = `Hello Bahurani Sarees, I'm interested in the "${product.name}" (${product.category}) priced at ${formatINR(product.price)}. Please share more details on availability and styling.`
  return whatsappHref(message)
}

export type Category = "Bridal Lehengas" | "Banarasi Silks" | "Designer Party Wear"

export type Badge = "Best Seller" | "Festive Discount 10% Off" | "Bridal Exclusive"

export type Product = {
  id: string
  name: string
  category: Category
  /** Numeric price in INR. */
  price: number
  /** Fabric / craftsmanship tag, e.g. "Hand-embroidered Zardozi". */
  craftTag: string
  badge?: Badge
  image: string
  description: string
}

export type PriceBand = {
  id: string
  label: string
  min: number
  max: number
}

export const PRICE_BANDS: PriceBand[] = [
  { id: "under-5k", label: "Under ₹5,000", min: 0, max: 4999 },
  { id: "5k-15k", label: "₹5,000 – ₹15,000", min: 5000, max: 15000 },
  { id: "15k-plus", label: "₹15,000+", min: 15001, max: Number.POSITIVE_INFINITY },
]

export const PRODUCTS: Product[] = [
  {
    id: "bl-1",
    name: "Rani Zardozi Bridal Lehenga",
    category: "Bridal Lehengas",
    price: 84999,
    craftTag: "Hand-embroidered Zardozi",
    badge: "Bridal Exclusive",
    image: "/bridal-lehenga.png",
    description:
      "Deep wedding red with heavy gold zardozi hand embroidery. A statement piece crafted for the modern bride.",
  },
  {
    id: "bl-2",
    name: "Crimson Pearl Heritage Lehenga",
    category: "Bridal Lehengas",
    price: 68500,
    craftTag: "Hand-embroidered Zardozi",
    badge: "Best Seller",
    image: "/bridal-lehenga-2.png",
    description:
      "Elaborate gold and pearl embroidery with a flowing dupatta. Regal craftsmanship for your big day.",
  },
  {
    id: "bl-3",
    name: "Golden Dawn Ceremony Lehenga",
    category: "Bridal Lehengas",
    price: 15000,
    craftTag: "Hand-embroidered Zardozi",
    badge: "Festive Discount 10% Off",
    image: "/bridal-lehenga.png",
    description:
      "An entry into couture bridal wear — lightweight zardozi detailing for the intimate ceremony.",
  },
  {
    id: "bs-1",
    name: "Maroon Banarasi Brocade Saree",
    category: "Banarasi Silks",
    price: 27999,
    craftTag: "Pure Katan Silk",
    badge: "Best Seller",
    image: "/banarasi-silk.png",
    description:
      "Pure Banarasi silk woven with intricate gold brocade. Timeless sheen and luxurious drape.",
  },
  {
    id: "bs-2",
    name: "Royal Red Floral Banarasi",
    category: "Banarasi Silks",
    price: 34500,
    craftTag: "Pure Katan Silk",
    image: "/banarasi-silk-2.png",
    description:
      "All-over gold floral weave with a rich golden border. A collector's heirloom silk.",
  },
  {
    id: "bs-3",
    name: "Ruby Handloom Banarasi",
    category: "Banarasi Silks",
    price: 5500,
    craftTag: "Pure Katan Silk",
    badge: "Festive Discount 10% Off",
    image: "/banarasi-silk.png",
    description:
      "Classic handloom Banarasi with a delicate gold zari border — everyday festive elegance.",
  },
  {
    id: "dp-1",
    name: "Wine Sequin Designer Saree",
    category: "Designer Party Wear",
    price: 11800,
    craftTag: "Georgette & Organza",
    badge: "Best Seller",
    image: "/party-wear.png",
    description:
      "Glamorous wine red with gold sequin embellishments and contemporary draping.",
  },
  {
    id: "dp-2",
    name: "Scarlet Shimmer Gown Saree",
    category: "Designer Party Wear",
    price: 8500,
    craftTag: "Georgette & Organza",
    image: "/party-wear-2.png",
    description:
      "Modern gown-saree silhouette with gold thread work and a subtle shimmer finish.",
  },
  {
    id: "dp-3",
    name: "Blush Organza Evening Saree",
    category: "Designer Party Wear",
    price: 3200,
    craftTag: "Georgette & Organza",
    badge: "Festive Discount 10% Off",
    image: "/party-wear.png",
    description:
      "Featherlight organza with subtle gold accents — an effortless pick for evening soirées.",
  },
]
