export type PageId = "home" | "collections" | "map" | "contact"

export const PAGES: { id: PageId; label: string }[] = [
  { id: "home", label: "Home" },
  { id: "collections", label: "Collections" },
  { id: "map", label: "Store & Map" },
  { id: "contact", label: "Contact" },
]
