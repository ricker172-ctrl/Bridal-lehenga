"use client"

import { useEffect, useState } from "react"
import { SiteNav } from "@/components/site-nav"
import { SiteFooter } from "@/components/site-footer"
import { HomePage } from "@/components/pages/home-page"
import { CollectionsPage } from "@/components/pages/collections-page"
import { MapPage } from "@/components/pages/map-page"
import { ContactPage } from "@/components/pages/contact-page"
import type { PageId } from "@/lib/pages"

export default function Page() {
  const [page, setPage] = useState<PageId>("home")

  const navigate = (id: PageId) => {
    setPage(id)
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  // Keep the top of the page in view on first paint.
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteNav current={page} onNavigate={navigate} />
      <main className="flex-1">
        {page === "home" && <HomePage onNavigate={navigate} />}
        {page === "collections" && <CollectionsPage />}
        {page === "map" && <MapPage />}
        {page === "contact" && <ContactPage />}
      </main>
      <SiteFooter />
    </div>
  )
}
