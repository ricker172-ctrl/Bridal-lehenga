"use client"

import { Phone, Menu, X } from "lucide-react"
import { useState } from "react"
import { STORE } from "@/lib/store"
import type { PageId } from "@/lib/pages"
import { PAGES } from "@/lib/pages"

export function SiteNav({
  current,
  onNavigate,
}: {
  current: PageId
  onNavigate: (id: PageId) => void
}) {
  const [open, setOpen] = useState(false)

  const go = (id: PageId) => {
    onNavigate(id)
    setOpen(false)
  }

  return (
    <header className="sticky top-0 z-50 border-b border-gold/30 bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <button
          onClick={() => go("home")}
          className="flex flex-col items-start text-left leading-none"
          aria-label={`${STORE.name} home`}
        >
          <span className="font-serif text-lg font-bold tracking-wide text-primary sm:text-xl">
            Bahurani
          </span>
          <span className="text-[0.6rem] font-medium uppercase tracking-[0.25em] text-accent">
            Sarees Store
          </span>
        </button>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Primary">
          {PAGES.map((page) => (
            <button
              key={page.id}
              onClick={() => onNavigate(page.id)}
              aria-current={current === page.id ? "page" : undefined}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                current === page.id
                  ? "bg-primary text-primary-foreground"
                  : "text-foreground/70 hover:bg-secondary hover:text-primary"
              }`}
            >
              {page.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={STORE.telHref}
            className="hidden items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-sm transition-transform hover:scale-[1.02] sm:inline-flex"
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            Call
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            className="inline-flex items-center justify-center rounded-full p-2 text-primary md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav
          className="border-t border-gold/20 bg-background px-4 pb-4 pt-2 md:hidden"
          aria-label="Mobile"
        >
          {PAGES.map((page) => (
            <button
              key={page.id}
              onClick={() => go(page.id)}
              aria-current={current === page.id ? "page" : undefined}
              className={`block w-full rounded-lg px-4 py-3 text-left text-sm font-medium ${
                current === page.id
                  ? "bg-secondary text-primary"
                  : "text-foreground/70"
              }`}
            >
              {page.label}
            </button>
          ))}
          <a
            href={STORE.telHref}
            className="mt-2 flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            Call Showroom Now
          </a>
        </nav>
      )}
    </header>
  )
}
