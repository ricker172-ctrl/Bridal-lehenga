"use client"

import { useEffect, useState } from "react"
import { STORE } from "@/lib/store"

type Status = { open: boolean; now: string } | null

function computeStatus(): { open: boolean; now: string } {
  const date = new Date()
  const minutes = date.getHours() * 60 + date.getMinutes()
  const open = minutes >= STORE.hours.openMinutes && minutes <= STORE.hours.closeMinutes
  const now = date.toLocaleTimeString("en-IN", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })
  return { open, now }
}

export function StoreStatus({ className = "" }: { className?: string }) {
  // Compute on the client only to avoid hydration mismatch with server time.
  const [status, setStatus] = useState<Status>(null)

  useEffect(() => {
    setStatus(computeStatus())
    const interval = setInterval(() => setStatus(computeStatus()), 30_000)
    return () => clearInterval(interval)
  }, [])

  if (!status) {
    return (
      <div
        className={`inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium text-muted-foreground ${className}`}
        aria-live="polite"
      >
        <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-muted-foreground/40" />
        Checking store hours…
      </div>
    )
  }

  return (
    <div
      className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold shadow-sm ring-1 ${
        status.open
          ? "bg-green-50 text-green-700 ring-green-600/20"
          : "bg-red-50 text-red-700 ring-red-600/20"
      } ${className}`}
      role="status"
      aria-live="polite"
    >
      <span
        className={`h-2.5 w-2.5 rounded-full ${
          status.open ? "bg-green-500 animate-pulse" : "bg-red-500"
        }`}
        aria-hidden="true"
      />
      {status.open ? "🟢 WE ARE OPEN NOW" : "🔴 SORRY, WE ARE CLOSED"}
      <span className="hidden font-normal opacity-70 sm:inline">· {status.now}</span>
    </div>
  )
}
