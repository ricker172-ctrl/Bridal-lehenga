"use client"

import { useEffect, useState, type FormEvent } from "react"
import { CheckCircle2, Phone, MessageCircle, Send, X } from "lucide-react"
import { STORE, whatsappHref } from "@/lib/store"

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({ name: "", mobile: "", message: "" })

  useEffect(() => {
    if (!submitted) return
    const timer = setTimeout(() => setSubmitted(false), 5000)
    return () => clearTimeout(timer)
  }, [submitted])

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSubmitted(true)
    setForm({ name: "", mobile: "", message: "" })
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 md:py-16">
      <header className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium uppercase tracking-[0.25em] text-accent">
          We&apos;d Love to Hear From You
        </p>
        <h1 className="mt-3 font-serif text-4xl font-bold text-primary sm:text-5xl">
          Contact &amp; Enquiries
        </h1>
        <p className="mt-4 font-display text-xl text-muted-foreground">
          Send us a message about a specific design, or reach us instantly by phone and WhatsApp.
        </p>
      </header>

      <div className="mt-10 grid gap-8 md:grid-cols-5">
        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="md:col-span-3 rounded-2xl border border-gold/25 bg-card p-6 shadow-sm sm:p-8"
        >
          <h2 className="font-serif text-xl font-semibold text-primary">Send an Enquiry</h2>
          <div className="mt-5 space-y-5">
            <div>
              <label htmlFor="name" className="mb-1.5 block text-sm font-medium text-foreground">
                Customer Name
              </label>
              <input
                id="name"
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Your full name"
                className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm outline-none ring-ring/40 focus:ring-2"
              />
            </div>
            <div>
              <label htmlFor="mobile" className="mb-1.5 block text-sm font-medium text-foreground">
                Mobile Number
              </label>
              <input
                id="mobile"
                type="tel"
                required
                inputMode="tel"
                pattern="[0-9+\s-]{7,15}"
                value={form.mobile}
                onChange={(e) => setForm((f) => ({ ...f, mobile: e.target.value }))}
                placeholder="+91 ..........."
                className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm outline-none ring-ring/40 focus:ring-2"
              />
            </div>
            <div>
              <label htmlFor="message" className="mb-1.5 block text-sm font-medium text-foreground">
                Enquire about a specific design
              </label>
              <textarea
                id="message"
                required
                rows={4}
                value={form.message}
                onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                placeholder="Tell us the design, colour or occasion you have in mind…"
                className="w-full resize-none rounded-lg border border-input bg-background px-4 py-2.5 text-sm outline-none ring-ring/40 focus:ring-2"
              />
            </div>
            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:scale-[1.01]"
            >
              <Send className="h-4 w-4" aria-hidden="true" />
              Submit Enquiry
            </button>
          </div>
        </form>

        {/* Quick contact */}
        <div className="md:col-span-2 space-y-4">
          <div className="rounded-2xl border border-gold/25 bg-secondary/50 p-6">
            <h2 className="font-serif text-xl font-semibold text-primary">Talk to Us Now</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Our showroom team is happy to help with styling and availability.
            </p>
            <a
              href={STORE.telHref}
              className="mt-4 flex items-center gap-3 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground"
            >
              <Phone className="h-4 w-4" aria-hidden="true" />
              {STORE.phoneDisplay}
            </a>
            <a
              href={whatsappHref(
                "Hello Bahurani Sarees, I have an enquiry about a design.",
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 flex items-center gap-3 rounded-full bg-[#25D366] px-5 py-3 text-sm font-semibold text-white"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              Chat on WhatsApp
            </a>
          </div>
          <div className="rounded-2xl border border-gold/25 bg-card p-6">
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">
              Showroom
            </p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {STORE.addressFull}
            </p>
            <p className="mt-3 text-sm text-muted-foreground">{STORE.hours.label}</p>
          </div>
        </div>
      </div>

      {/* Success popup */}
      {submitted && (
        <div
          className="fixed inset-x-0 bottom-6 z-[60] flex justify-center px-4"
          role="status"
          aria-live="assertive"
        >
          <div className="flex items-start gap-3 rounded-2xl border border-green-600/20 bg-white px-5 py-4 shadow-2xl ring-1 ring-black/5">
            <CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0 text-green-600" aria-hidden="true" />
            <div>
              <p className="font-serif text-base font-semibold text-primary">
                Enquiry Sent Successfully!
              </p>
              <p className="mt-0.5 text-sm text-muted-foreground">
                Thank you — our team will contact you shortly.
              </p>
            </div>
            <button
              onClick={() => setSubmitted(false)}
              className="ml-2 rounded-full p-1 text-muted-foreground hover:bg-secondary"
              aria-label="Dismiss notification"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
