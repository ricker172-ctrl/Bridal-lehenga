"use client"

import { MapPin, Navigation, Car, Clock, Phone } from "lucide-react"
import { STORE } from "@/lib/store"

export function MapPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 md:py-16">
      <header className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium uppercase tracking-[0.25em] text-accent">
          Visit The Showroom
        </p>
        <h1 className="mt-3 font-serif text-4xl font-bold text-primary sm:text-5xl">
          Find Us in Dhanbad
        </h1>
      </header>

      {/* Address banner */}
      <div className="mt-8 flex flex-col items-center gap-3 rounded-2xl border border-gold/30 bg-primary px-6 py-5 text-center text-primary-foreground sm:flex-row sm:justify-center sm:text-left">
        <MapPin className="h-6 w-6 shrink-0 text-accent" aria-hidden="true" />
        <p className="font-display text-lg font-medium sm:text-xl">{STORE.addressFull}</p>
      </div>

      {/* Map */}
      <div className="mt-8 overflow-hidden rounded-2xl border border-gold/30 shadow-lg">
        <iframe
          title="Map showing Bahurani Sarees Store location in Dhanbad"
          src="https://www.google.com/maps?q=Park%20Market%2C%20Hirapur%2C%20Dhanbad%2C%20Jharkhand%20826007&z=15&output=embed"
          className="h-[360px] w-full border-0 md:h-[440px]"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
      </div>

      <div className="mt-6 flex justify-center">
        <a
          href={STORE.mapsHref}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:scale-[1.03]"
        >
          <Navigation className="h-4 w-4" aria-hidden="true" />
          Open in Google Maps for Live Navigation
        </a>
      </div>

      {/* Metrics */}
      <div className="mt-10 grid gap-5 sm:grid-cols-3">
        <div className="rounded-2xl border border-gold/25 bg-card p-6 text-center shadow-sm">
          <span className="mx-auto inline-flex h-11 w-11 items-center justify-center rounded-full bg-green-50 text-green-600">
            <Car className="h-5 w-5" aria-hidden="true" />
          </span>
          <p className="mt-3 text-sm text-muted-foreground">Live Parking Status</p>
          <p className="mt-1 font-serif text-lg font-semibold text-green-600">Available</p>
        </div>
        <div className="rounded-2xl border border-gold/25 bg-card p-6 text-center shadow-sm">
          <span className="mx-auto inline-flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-primary">
            <Clock className="h-5 w-5" aria-hidden="true" />
          </span>
          <p className="mt-3 text-sm text-muted-foreground">Estimated Transit Time</p>
          <p className="mt-1 font-serif text-lg font-semibold text-primary">~ 12 mins from City Centre</p>
        </div>
        <div className="rounded-2xl border border-gold/25 bg-card p-6 text-center shadow-sm">
          <span className="mx-auto inline-flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-primary">
            <Phone className="h-5 w-5" aria-hidden="true" />
          </span>
          <p className="mt-3 text-sm text-muted-foreground">Call Before Visit</p>
          <a
            href={STORE.telHref}
            className="mt-1 block font-serif text-lg font-semibold text-primary hover:text-accent"
          >
            {STORE.phoneDisplay}
          </a>
        </div>
      </div>
    </div>
  )
}
