"use client"

import { useMemo, useState } from "react"
import Image from "next/image"
import { MessageCircle, SlidersHorizontal } from "lucide-react"
import {
  PRODUCTS,
  PRICE_BANDS,
  formatINR,
  productWhatsappHref,
  type Badge,
  type Category,
} from "@/lib/store"

const CATEGORIES: Category[] = ["Bridal Lehengas", "Banarasi Silks", "Designer Party Wear"]

const BADGE_STYLES: Record<Badge, string> = {
  "Best Seller": "bg-gold text-primary",
  "Festive Discount 10% Off": "bg-primary text-primary-foreground",
  "Bridal Exclusive": "bg-accent text-accent-foreground",
}

export function CollectionsPage() {
  const [activeBand, setActiveBand] = useState<string | null>(null)

  const visibleProducts = useMemo(() => {
    if (!activeBand) return PRODUCTS
    const band = PRICE_BANDS.find((b) => b.id === activeBand)
    if (!band) return PRODUCTS
    return PRODUCTS.filter((p) => p.price >= band.min && p.price <= band.max)
  }, [activeBand])

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 md:py-16">
      <header className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium uppercase tracking-[0.25em] text-accent">
          The Collection
        </p>
        <h1 className="mt-3 font-serif text-4xl font-bold text-primary sm:text-5xl">
          Curated for Every Celebration
        </h1>
        <p className="mt-4 font-display text-xl text-muted-foreground">
          From once-in-a-lifetime bridal couture to statement party wear — filter by budget
          and enquire instantly on WhatsApp.
        </p>
      </header>

      {/* Interactive price filter */}
      <div className="mt-10 rounded-2xl border border-gold/25 bg-card p-5 shadow-sm">
        <div className="flex items-center gap-2 text-sm font-medium uppercase tracking-[0.15em] text-accent">
          <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
          Filter by price
        </div>
        <div className="mt-4 flex flex-wrap gap-3" role="group" aria-label="Filter products by price">
          <FilterButton
            label="All Prices"
            active={activeBand === null}
            onClick={() => setActiveBand(null)}
          />
          {PRICE_BANDS.map((band) => (
            <FilterButton
              key={band.id}
              label={band.label}
              active={activeBand === band.id}
              onClick={() => setActiveBand(band.id)}
            />
          ))}
        </div>
      </div>

      {CATEGORIES.map((category) => {
        const items = visibleProducts.filter((p) => p.category === category)
        if (items.length === 0) return null

        return (
          <section key={category} className="mt-14">
            <div className="mb-6 flex items-center gap-4">
              <h2 className="font-serif text-2xl font-semibold text-primary">{category}</h2>
              <span className="h-px flex-1 bg-gold/40" aria-hidden="true" />
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-2">
              {items.map((product) => (
                <article
                  key={product.id}
                  className="group flex flex-col overflow-hidden rounded-2xl border border-gold/25 bg-card shadow-sm transition-shadow hover:shadow-xl sm:flex-row"
                >
                  <div className="relative aspect-[4/5] w-full shrink-0 overflow-hidden sm:aspect-auto sm:w-40 md:w-48">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      sizes="(max-width: 640px) 90vw, 200px"
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    {product.badge && (
                      <span
                        className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-semibold shadow-sm ${BADGE_STYLES[product.badge]}`}
                      >
                        {product.badge}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <span className="inline-flex w-fit items-center rounded-full border border-gold/40 px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wide text-accent">
                      {product.craftTag}
                    </span>
                    <h3 className="mt-2 font-serif text-lg font-semibold text-primary">
                      {product.name}
                    </h3>
                    <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">
                      {product.description}
                    </p>
                    <div className="mt-4 flex items-center justify-between gap-3">
                      <span className="font-display text-xl font-semibold text-primary">
                        {formatINR(product.price)}
                      </span>
                      <a
                        href={productWhatsappHref(product)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition-transform hover:scale-[1.03]"
                      >
                        <MessageCircle className="h-4 w-4" aria-hidden="true" />
                        Query on WhatsApp
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>
        )
      })}

      {visibleProducts.length === 0 && (
        <p className="mt-14 text-center font-display text-lg text-muted-foreground">
          No pieces in this price range right now. Try another budget or message us for a
          custom order.
        </p>
      )}
    </div>
  )
}

function FilterButton({
  label,
  active,
  onClick,
}: {
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
        active
          ? "border-primary bg-primary text-primary-foreground shadow-sm"
          : "border-gold/40 bg-transparent text-foreground hover:border-primary hover:text-primary"
      }`}
    >
      {label}
    </button>
  )
}
