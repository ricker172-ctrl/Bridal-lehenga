"use client"

import Image from "next/image"
import { Phone, Sparkles, Gem, HandHeart, ArrowRight } from "lucide-react"
import { STORE } from "@/lib/store"
import { StoreStatus } from "@/components/store-status"
import type { PageId } from "@/lib/pages"

export function HomePage({ onNavigate }: { onNavigate: (id: PageId) => void }) {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 sm:px-6 md:grid-cols-2 md:py-20">
          <div className="order-2 md:order-1">
            <StoreStatus className="mb-6" />
            <p className="mb-3 flex items-center gap-2 text-sm font-medium uppercase tracking-[0.25em] text-accent">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              {STORE.addressShort}
            </p>
            <h1 className="text-balance font-serif text-4xl font-bold leading-tight text-primary sm:text-5xl md:text-6xl">
              {STORE.tagline}
            </h1>
            <p className="mt-5 max-w-md font-display text-xl leading-relaxed text-muted-foreground">
              Handpicked Banarasi silks, regal bridal lehengas and designer party wear —
              woven with heritage, finished with gold.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                href={STORE.telHref}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-transform hover:scale-[1.03]"
              >
                <Phone className="h-4 w-4" aria-hidden="true" />
                Call Showroom Now
              </a>
              <button
                onClick={() => onNavigate("collections")}
                className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-card px-6 py-3.5 text-sm font-semibold text-primary transition-colors hover:bg-secondary"
              >
                Explore Collections
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <div className="relative mx-auto aspect-[3/4] w-full max-w-sm overflow-hidden rounded-[2rem] border-4 border-gold/40 shadow-2xl">
              <Image
                src="/hero-bride.png"
                alt="Indian bride wearing an ornate royal red and gold bridal lehenga"
                fill
                priority
                sizes="(max-width: 768px) 90vw, 400px"
                className="object-cover"
              />
              <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-white/20" />
            </div>
          </div>
        </div>
        <div
          className="pointer-events-none absolute -right-24 top-1/2 -z-10 h-96 w-96 -translate-y-1/2 rounded-full bg-accent/10 blur-3xl"
          aria-hidden="true"
        />
      </section>

      {/* Value props */}
      <section className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <div className="grid gap-5 sm:grid-cols-3">
          {[
            {
              icon: Gem,
              title: "Pure Heritage Weaves",
              text: "Authentic Banarasi silk and hand-worked zari from master artisans.",
            },
            {
              icon: HandHeart,
              title: "Bridal Styling",
              text: "Personal consultation to find the perfect ensemble for your day.",
            },
            {
              icon: Sparkles,
              title: "Exclusive Designer Range",
              text: "Contemporary party wear you won't find anywhere else in Dhanbad.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-2xl border border-gold/25 bg-card p-6 shadow-sm"
            >
              <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-primary">
                <item.icon className="h-5 w-5" aria-hidden="true" />
              </span>
              <h3 className="mt-4 font-serif text-lg font-semibold text-primary">
                {item.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {item.text}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
