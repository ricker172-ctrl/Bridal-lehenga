"use client"

import { Phone, MapPin, MessageCircle, Clock } from "lucide-react"
import { STORE, whatsappHref } from "@/lib/store"

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-gold/30 bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <p className="font-serif text-2xl font-bold">Bahurani</p>
          <p className="mt-1 text-xs uppercase tracking-[0.25em] text-accent">
            Sarees Store
          </p>
          <p className="mt-4 max-w-xs font-display text-lg leading-relaxed text-primary-foreground/80">
            Curating the finest bridal and heritage wear for discerning families since generations.
          </p>
        </div>

        <div className="space-y-3 text-sm">
          <p className="font-semibold uppercase tracking-wider text-accent">Reach Us</p>
          <a href={STORE.telHref} className="flex items-center gap-3 hover:text-accent">
            <Phone className="h-4 w-4 text-accent" aria-hidden="true" />
            {STORE.phoneDisplay}
          </a>
          <a
            href={whatsappHref("Hello Bahurani Sarees, I would like to enquire about your collection.")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 hover:text-accent"
          >
            <MessageCircle className="h-4 w-4 text-accent" aria-hidden="true" />
            Chat on WhatsApp
          </a>
          <p className="flex items-start gap-3 text-primary-foreground/80">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
            {STORE.addressFull}
          </p>
        </div>

        <div className="space-y-3 text-sm">
          <p className="font-semibold uppercase tracking-wider text-accent">Showroom Hours</p>
          <p className="flex items-center gap-3 text-primary-foreground/80">
            <Clock className="h-4 w-4 text-accent" aria-hidden="true" />
            {STORE.hours.label}
          </p>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10 py-5 text-center text-xs text-primary-foreground/60">
        © {new Date().getFullYear()} {STORE.name}. All rights reserved.
      </div>
    </footer>
  )
}
